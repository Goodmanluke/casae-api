-- Initial Casae schema

CREATE TABLE IF NOT EXISTS users (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    email text NOT NULL UNIQUE,
    hashed_password text,
    full_name text,
    role text DEFAULT 'user',
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS orgs (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    name text NOT NULL,
    owner_id uuid REFERENCES users(id),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS properties (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    org_id uuid REFERENCES orgs(id),
    address text NOT NULL,
    lat double precision,
    lng double precision,
    raw_data jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS analyses (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    property_id uuid REFERENCES properties(id) ON DELETE CASCADE,
    created_by uuid REFERENCES users(id),
    status text,
    avm numeric,
    avm_range_lower numeric,
    avm_range_upper numeric,
    quality_score numeric,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS comps (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    analysis_id uuid REFERENCES analyses(id) ON DELETE CASCADE,
    comp_address text NOT NULL,
    distance numeric,
    sale_date date,
    sale_price numeric,
    features jsonb,
    similarity_score numeric,
    selected boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS scenarios (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    analysis_id uuid REFERENCES analyses(id) ON DELETE CASCADE,
    items jsonb,
    cost_total numeric,
    arv numeric,
    arv_range_lower numeric,
    arv_range_upper numeric,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS cost_items (
    id serial PRIMARY KEY,
    name text NOT NULL,
    unit_type text NOT NULL,
    cost_low numeric,
    cost_medium numeric,
    cost_high numeric,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS reports (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    analysis_id uuid REFERENCES analyses(id) ON DELETE CASCADE,
    scenario_id uuid REFERENCES scenarios(id) ON DELETE CASCADE,
    pdf_url text,
    version text,
    assumptions jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS billing (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid REFERENCES users(id),
    org_id uuid REFERENCES orgs(id),
    plan text,
    reports_used integer DEFAULT 0,
    credits integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS zip_multipliers (
    id serial PRIMARY KEY,
    zip_prefix text NOT NULL,
    cost_multiplier numeric NOT NULL DEFAULT 1.0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);